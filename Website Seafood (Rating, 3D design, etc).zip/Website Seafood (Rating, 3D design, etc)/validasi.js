function validationForm(){
	var name = document.getElementById("itNama").value;
	var username = document.getElementById("itUsername").value;
	var password = document.getElementById("itPassword").value;
	var gender = document.getElementsByName("gender");
	var email = document.getElementById("itEmail").value;
	var errorMessageV = document.getElementById("itError");


	if (name == "") {
		errorMessageV.innerHTML = "Nama harus diisi";
	}else if (letterOnly(name) == false) {
		errorMessageV.innerHTML = "Nama tidak boleh mengandung angka";
	}else if (username == "") {
		errorMessageV.innerHTML = "Username harus diisi";
	}else if (username.length <= 5) {
		errorMessageV.innerHTML = "Karakter username harus lebih dari 5";
	}else if (password == "") {
		errorMessageV.innerHTML = "Password harus diisi";
	}else if (password.length <= 7) {
		errorMessageV.innerHTML = "Karakter password harus lebih dari 7";
	}else if (alphaNumeric(password) == false) {
		errorMessageV.innerHTML = "Password harus mengandung alpha-numeric";
	}else if (gender[0].checked == false && gender[1].checked == false) {
		errorMessageV.innerHTML = "Gender harus dipilih";
	}else if(email == ""){
		errorMessageV.innerHTML = "Email harus diisi"
	}else if (validEmail(email) == false) {
		errorMessageV.innerHTML = "Email harus mengandung '@' dan '.'";
	}else{
		window.location.href = "login.html";
		document.getElementById("btnReset").click();
		errorMessageV.innerHTML = "";
		window.localStorage.setItem('itUsername',username);
    	window.localStorage.setItem('itPassword',password);
	}
}

function user_login(us, ps){
	var username = window.localStorage.getItem('itUsername');
	var password = window.localStorage.getItem('itPassword');

	if (us == username && ps == password) {
		return true;
	}
	return false;
}


function feedbackForm(){
	var nama = document.getElementById("fbNama").value;
	var email = document.getElementById("fbEmail").value;
	var feedback = document.getElementById("fbFeedback").value;
	var errorMessageF = document.getElementById("fbError");

	if (nama == "") {
		errorMessageF.innerHTML = "Nama harus diisi";
	}else if (email == "") {
		errorMessageF.innerHTML = "Email harus diisi";
	}else if (feedback == "") {
		errorMessageF.innerHTML = "Feedback harus diisi";
	}else{
		alert("Terima Kasih, Feedbak telah kami terima.");
		document.getElementById("btnReset").click();
		errorMessageF.innerHTML = "";
	}
}

function forum(){
	var frForum = document.getElementById("frForum").value;
	var errorMessageFR = document.getElementById("frError");

	if (frForum == "") {
		errorMessageFR.innerHTML = "Forum harus diisi";
	}else{
		alert("Forum sukses di kirim");
	}
}



function letterOnly(name){
	var a = 0;
	for(i = 0; i < name.length; i++){
		if ((name.charCodeAt(i) < 65 || name.charCodeAt(i) > 90) && (name.charCodeAt(i) < 97 || name.charCodeAt(i) > 122 )) a++; 
	}
	if (a == 0) {
		return true;
	}else{
		return false;
	}
}

function alphaNumeric(password){
    var alpha = 0;
    var num = 0;
    for(var i = 0; i < password.length; i++){
        var ps = +password.charCodeAt(i);
        if(ps >= 65 && ps <= 90) alpha++;
        if(ps >= 97 && ps <= 122) alpha++;
        if(ps >= 48 && ps <= 57) num++;
    }
    if(alpha == 0 || num == 0){
        return false;
    }else{
        return true;
    }
}

function validEmail(email){
    var a = 0;
    var sc = 0;
    for(var i = 0; i < email.length; i++){
        if((email.charCodeAt(i) < 65 || email.charCodeAt(i) > 90) && (email.charCodeAt(i) < 97 || email.charCodeAt(i) > 122) && (email.charCodeAt(i) < 48 || email.charCodeAt(i) > 57)) a++;
        if(email.charCodeAt(i) == 64 || email.charCodeAt(i) == 46) sc++;
    }
    var c = a-sc;
    if(c == 0 && sc >= 2){
        return true;
    }else{
        return false;
    }
}

